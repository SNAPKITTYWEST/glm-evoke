# GLM-Transformer-Evoke

Sovereign, local-first pipeline for ingesting GLM checkpoints, sealing weights WORM, and evoking an observable execution graph.

## Layout

- `src/config.rs` — `GlmConfig` parsing + invariant validation
- `src/worm.rs` — Write-Once-Read-Many memory manager (staging -> seal -> RO)
- `src/transform.rs` — parallel safetensors ingest, GLM key mapping, shape assertion before alloc, fused QKV + MLP gate/up splits
- `src/graph.rs` — sealed `ExecutionGraph` + per-layer views
- `src/evoke.rs` — `Evoker::evoke()` (ingest -> seal -> compile) and observable `generate_first_token()` loop
- `src/backend.rs` — `TensorBackend` trait (`CpuBackend` included; plug vLLM / custom engine)
- `src/telemetry.rs` — `TelemetrySink`, auditable `ExecutionRecord` stream

## Build

```bash
cargo build
cargo test
```

## Use

```rust
let cfg = GlmConfig::from_json_str(&std::fs::read_to_string("config.json")?)?;
let evoker = Evoker::evoke(cfg, vec!["model.safetensors".into()], Arc::new(CpuBackend), Arc::new(TracingSink::new())).await?;
let (tok, mut records) = evoker.generate_first_token(vec![1, 2, 3]).await?;
```

Every phase (`map`, `seal`, `compile`, `forward`, `sample`) emits an `ExecutionRecord` — no hidden chain-of-thought.
